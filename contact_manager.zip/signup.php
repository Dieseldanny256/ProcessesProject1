<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$firstname = $data['firstname'];
$lastname = $data['lastname'];
$username = $data['username'];
$password = $data['password'];

// Adding users to the database
$stmt = $conn->prepare("INSERT INTO Users (FirstName, LastName, Login, Password) VALUES (:firstname, :lastname, :username, SHA2(:password, 256))");
$stmt->bindParam(':firstname', $firstname);
$stmt->bindParam(':lastname', $lastname);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Account created successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to create account"]);
}
?>
