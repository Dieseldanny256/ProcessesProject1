<?php
require 'db.php'; 

$data = json_decode(file_get_contents("php://input"), true); //This is to receive the JSON data from clients

$username = $data['username'];
$password = $data['password'];

// Checking username & password in database
$stmt = $conn->prepare("SELECT * FROM Users WHERE Login = :username AND Password = SHA2(:password, 256)");
$stmt->bindParam(':username', $username);
$stmt->bindParam(':password', $password);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(["status" => "success", "user" => $user]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid credentials"]);
}
?>
