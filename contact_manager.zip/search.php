<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$userid = $data['userid'];
$keyword = "%" . $data['keyword'] . "%";

// Tìm kiếm danh bạ
$stmt = $conn->prepare("SELECT * FROM Contacts WHERE UserID = :userid AND (FirstName LIKE :keyword OR LastName LIKE :keyword)");
$stmt->bindParam(':userid', $userid);
$stmt->bindParam(':keyword', $keyword);
$stmt->execute();

$contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($contacts);
?>
