<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$firstname = $data['firstname'];
$lastname = $data['lastname'];
$phone = $data['phone'];
$email = $data['email'];
$userid = $data['userid'];

// Adding contacts to the database
$stmt = $conn->prepare("INSERT INTO Contacts (FirstName, LastName, Phone, Email, UserID) VALUES (:firstname, :lastname, :phone, :email, :userid)");
$stmt->bindParam(':firstname', $firstname);
$stmt->bindParam(':lastname', $lastname);
$stmt->bindParam(':phone', $phone);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':userid', $userid);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Contact added successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to add contact"]);
}
?>
